package edu.txstate.tlt105.carrentapi;

import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.message.BasicHeader;

public class Main2Activity extends ListActivity {

    List<Car> cars ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      //  setContentView(R.layout.activity_main2);
        getCars();


    }

    void getCars(){
        List<Header> headers = new ArrayList<>();
        headers.add(new BasicHeader("Accept", "application/json"));
        RestAPI.get(Main2Activity.this, "cars.json", headers.toArray(new Header[headers.size()]),
                null, new JsonHttpResponseHandler() {
                    public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                        //Make an array of Attraction objects
                        cars = new ArrayList<Car>();
                        for (int i=0; i <response.length(); i++){
                            try {
                                cars.add(new Car(response.getJSONObject(i)));
                            } catch (Exception ex ) {ex.printStackTrace();}
                        }
                        setListAdapter(new ArrayAdapter<Car>(Main2Activity.this, R.layout.activity_main2,
                                R.id.txtlist , cars));
                    }
                });

    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {//position = index
        super.onListItemClick(l, v, position, id);
        if (position == 100) {
            //Toast.makeText(MainActivity.this, "You select Art Institute.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://artic.edu")));
        } else {


            Car selectedCar =  cars.get(position);

            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(Main2Activity.this);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putInt("Id", selectedCar.getId());
            editor.putString("Name", selectedCar.getName());
            editor.putString("brand", selectedCar.getBrand());
            editor.putString("color", selectedCar.getColor());
            editor.putFloat("rentalCost", (float) selectedCar.getRentalCost());
            editor.putInt("pos", position);
            editor.commit();


            startActivity(new Intent(Main2Activity.this, Carinfo.class));


            DecimalFormat tenth = new DecimalFormat("$###,###.##");
            Toast.makeText(Main2Activity.this, "You select " + selectedCar.getName() +
                    ", the cost is " + tenth.format(selectedCar.getRentalCost())+".", Toast.LENGTH_LONG).show();
        }

        //look up selected element in the array
        //String strSelectedAttraction= strAttractions[position];
        //Toast.makeText(MainActivity.this, "You select " + strSelectedAttraction + ".", Toast.LENGTH_LONG).show();



    }





}
