package edu.txstate.tlt105.carrentapi;

import org.json.JSONObject;

public class Car {
    private int Id;
    private String Name;
    private String brand;
    private String color;
    private double rentalCost;



    public Car() {

    }


    public Car (JSONObject object){
        try {
            this.Id = object.getInt("Id");
            this.Name = object.getString("Name");
            this.brand = object.getString("brand");
            this.color = object.getString("color");
            this.rentalCost = object.getDouble("rentalCost");

        }catch (Exception ex){ex.printStackTrace();}


    }



    public Car(int Id, String Name, String brand, String color, double rentalCost ){

        this.Id = Id;
        this.Name = Name;
        this.brand = brand;
        this.color = color ;
        this.rentalCost=rentalCost;


    }
    public int getId() {
        return Id;
    }

    public void setId(int id) {
        this.Id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }


    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getRentalCost() {
        return rentalCost;
    }

    public void setRentalCost(double rentalCost) {
        this.rentalCost = rentalCost;
    }

    @Override
    public String toString() {
        return this.Name + ", " + this.Id;
    }



}
