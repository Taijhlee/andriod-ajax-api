package edu.txstate.tlt105.carrentapi;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.TextHttpResponseHandler;

import java.text.DecimalFormat;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;


public class Carinfo extends AppCompatActivity {

    int intId;
    String strName;
    double dblrentalCost;
    String strBrand;
    String strColor;
    int position;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carinfo);

        SharedPreferences sharedPref2 = PreferenceManager.getDefaultSharedPreferences(this);
        intId = sharedPref2.getInt("Id", 0);
        strName = sharedPref2.getString("Name", "");
        strBrand = sharedPref2.getString("brand", "");
        strColor = sharedPref2.getString("color", "");
        dblrentalCost = sharedPref2.getFloat("rentalCost", 0);
        position =   sharedPref2.getInt("pos", 0);

        final TextView namey = findViewById(R.id.txtName);
        final TextView ids = findViewById(R.id.txId);
        final TextView brandy = findViewById(R.id.txtBrand);
        final TextView colory= findViewById(R.id.txtColor);

        DecimalFormat format = new DecimalFormat("$###,###.##");
        DecimalFormat formaty = new DecimalFormat("###,###");


         String strid =formaty.format(intId);



        namey.setText(strName);
        ids.setText(strid);
        brandy.setText(strBrand);
        colory.setText(strColor);




        Button costCalculation = findViewById(R.id.calcuCostBtn);

        final EditText numberOfRentaldays = findViewById(R.id.editRentaldays);

        costCalculation.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                int intRentaldays = Integer.parseInt(numberOfRentaldays.getText().toString());
               if(intRentaldays> 30){

                   Toast.makeText(Carinfo.this, " For rental days larger than 30 DAYS Please Call 512-777-2222. " , Toast.LENGTH_LONG).show();

               }
               else {

                   double dblTotalCost = dblrentalCost * intRentaldays;
                   DecimalFormat currency = new DecimalFormat("$###,###.##");
                   Toast.makeText(Carinfo.this, "Total Cost:" +
                           currency.format(dblTotalCost) + ".", Toast.LENGTH_LONG).show();


               }

            }
        });


        Button update = findViewById(R.id.Updatebtn);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent activity2 = new Intent(getApplicationContext(), UpdateRentalCost.class);
                startActivity(activity2);
            }
        });



    }
}
