package edu.txstate.tlt105.carrentapi;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.TextHttpResponseHandler;

import java.text.DecimalFormat;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

public class UpdateRentalCost extends AppCompatActivity {

    int intId2;
    String strName2;
    double dblrentalCost2;
    int position;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_rental_cost);

        SharedPreferences sharedPref2 = PreferenceManager.getDefaultSharedPreferences(this);
        intId2 = sharedPref2.getInt("Id", 0);
        strName2 = sharedPref2.getString("Name", "");
       // strBrand = sharedPref2.getString("brand", "");
      //  strColor = sharedPref2.getString("color", "");
        dblrentalCost2 = sharedPref2.getFloat("rentalCost", 0);
        position =   sharedPref2.getInt("pos", 0);

        final EditText newrentalcost = findViewById(R.id.newRentalday);
        Button update2 = findViewById(R.id.Updatrenbtn);

        final TextView namey2 = findViewById(R.id.txtName2);
        final TextView ids2 = findViewById(R.id.txtid2);
        final TextView brandy = findViewById(R.id.txtBrand);
        final TextView colory= findViewById(R.id.txtColor);

        DecimalFormat format = new DecimalFormat("$###,###.##");
        DecimalFormat formaty = new DecimalFormat("###,###");


        String strid2 =formaty.format(intId2);



        namey2.setText(strName2);
        ids2.setText(strid2);


        update2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "cars/" +position+ "/rentalCost.json";
                StringEntity entity = null;
                double dblRentalcost = Double.parseDouble(newrentalcost.getText().toString());

                try {
                    double newCost = dblRentalcost;
                    entity = new StringEntity("" + newCost); // This is a number without \".
                }  catch(Exception ex) {
                    ex.printStackTrace();
                }


                entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/text"));
                RestAPI.put(UpdateRentalCost.this, url, entity,
                        "application/text", new TextHttpResponseHandler(){
                            @Override
                            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                                Toast.makeText(UpdateRentalCost.this, "success", Toast.LENGTH_LONG).show();

                            }
                            @Override
                            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                                Toast.makeText(UpdateRentalCost.this, responseString, Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });



    }
}
